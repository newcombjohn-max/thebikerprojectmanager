@echo off
rem Opens the Command Center at http://localhost:8765 so the browser remembers the microphone and other permissions.
rem See Command_Center_Launcher.ps1 for what it does. Close this window any time; the page keeps working.
start "" powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0Command_Center_Launcher.ps1"
