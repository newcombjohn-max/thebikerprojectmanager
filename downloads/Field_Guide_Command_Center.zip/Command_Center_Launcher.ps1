# Opens the Field Guide Command Center at a fixed address on this computer (http://localhost:8765), so the browser remembers
# permissions such as the microphone, which it will not do for a page opened as a file. Only this computer can reach it, it
# only hands out the app page and its guides from this folder (never workbooks or other files), and it stops by itself after
# 12 hours without use. Started by "Open Command Center.cmd"; running it again just opens the page.
param([int]$Port = 8765, [switch]$NoBrowser, [int]$IdleHours = 12)
$root = $PSScriptRoot
$page = 'Field_Guide_Command_Center.html'
$url = "http://localhost:$Port/$page"
$types = @{ '.html' = 'text/html; charset=utf-8'; '.pdf' = 'application/pdf'; '.png' = 'image/png'; '.svg' = 'image/svg+xml'; '.ico' = 'image/x-icon' }
$l = New-Object System.Net.HttpListener
$l.Prefixes.Add("http://localhost:$Port/")
try { $l.Start() } catch {
  # already running (or the port is taken): just open the page
  if (-not $NoBrowser) { Start-Process $url }
  exit 0
}
if (-not $NoBrowser) { Start-Process $url }
$last = Get-Date
while ($l.IsListening) {
  $task = $l.GetContextAsync()
  while (-not $task.Wait(60000)) {
    if (((Get-Date) - $last).TotalHours -ge $IdleHours) { $l.Stop(); exit 0 }
  }
  $c = $task.Result
  $last = Get-Date
  $res = $c.Response
  try {
    $name = [Uri]::UnescapeDataString($c.Request.Url.AbsolutePath.TrimStart('/'))
    if ($name -eq '') { $res.Redirect("/$page"); continue }
    $ext = [IO.Path]::GetExtension($name).ToLower()
    $file = Join-Path $root $name
    $inside = [IO.Path]::GetFullPath($file).StartsWith([IO.Path]::GetFullPath($root) + [IO.Path]::DirectorySeparatorChar)
    if ($c.Request.HttpMethod -ne 'GET') { $res.StatusCode = 405 }
    elseif (-not $inside -or $name.Contains('/') -or $name.Contains('\') -or -not $types.ContainsKey($ext) -or -not (Test-Path -LiteralPath $file -PathType Leaf)) { $res.StatusCode = 404 }
    else {
      $bytes = [IO.File]::ReadAllBytes($file)
      $res.ContentType = $types[$ext]
      $res.Headers.Add('Cache-Control', 'no-cache')
      $res.ContentLength64 = $bytes.Length
      $res.OutputStream.Write($bytes, 0, $bytes.Length)
    }
  } catch { $res.StatusCode = 500 } finally { $res.Close() }
}
